<style>
    .footer{
        background-color: #333;
        padding:100px 0;
    }
</style>
<footer class="footer">
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="text-center text-white">
                All Rights Reserved Test Series
            </div>
        </div>
    </div>
</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
